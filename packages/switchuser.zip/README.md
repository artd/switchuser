# switchuser
For Joomla 3. By simply clicking a button, an administrator can switch to a different user without logging in and check their permissions or troubleshooting problems.&lt;br />Note: Please enable plugin first in the plugin manager
